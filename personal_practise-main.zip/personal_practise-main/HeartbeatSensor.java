// HeartbeatSensor.java
public class HeartbeatSensor {
    public int measureHeartbeat() {
        // Simulate measuring heartbeat
        return (int) (Math.random() * 100 + 60);  // Simulates a heartbeat between 60 and 160 BPM
    }
}



