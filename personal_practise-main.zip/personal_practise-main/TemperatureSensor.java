public class TemperatureSensor {
    public double measureTemperature() {
        // Simulate measuring temperature
        return 36.5 + (Math.random() * 2 - 1);  // Simulates a temperature between 35.5 and 37.5 degrees Celsius
    }
}